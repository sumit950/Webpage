<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADVENT</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="#hero">Home</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
        </nav>
<style>
background-image: url("C:\Users\Sumit\Downloads.jpg");
background-size: cover;
background-position: center;
height: 1000vh;
display: flex;
justify-content: center;
align-items: center;
text-align: center;
flex-direction: column;
<section id="formSection">
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        /* CSS to center the form */
        body, html {
            height: 100%;
            margin: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: black;
        }

        main {
            width: 100%;
            max-width: 500px;
            padding: 20px;
            background-color: black;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 15px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        textarea {
            resize: vertical;
            height: 150px;
        }

        button {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        button:hover {
            background-color: black;
        }

        /* Success message styling */
        .success-message {
            display: none;
            color: green;
            background-color: black;
            border: 1px solid #d0e9c6;
            padding: 10px;
            border-radius: 5px;
            margin-top: 15px;
            text-align: center;
        }
    </style>
</head>
<body>

<main>
    <h2>Contact Us</h2>
    <form id="contactForm" onsubmit="return submitForm(event)">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>

        <div class="form-group">
            <label for="number">Number:</label>
            <input type="text" id="number" name="number" required>
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="organization">Organization Name:</label>
            <input type="text" id="organization" name="organization" required>
        </div>

        <div class="form-group">
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
        </div>

        <button type="submit">Submit</button>
    </form>
    <div id="successMessage" class="success-message"></div>
</main>

<script>
    // Submit Form and Show Success Message
    function submitForm(event) {
        event.preventDefault(); // Prevent form from submitting normally

        // Display success message
        const successMessage = document.getElementById('successMessage');
        successMessage.textContent = 'Form submitted successfully!';
        successMessage.style.display = 'block';

        // Hide success message after 5 seconds
        setTimeout(() => {
            successMessage.style.display = 'none';
            document.getElementById('contactForm').reset(); // Reset form fields after success message disappears
        }, 5000);
    }
</script>

</body>
</html>


 
   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3767.3588026220987!2d73.10546507498134!3d19.223188382011955!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be795eb2140fdbf%3A0x36d96397bde202c!2sKeraleeya%20Samajam&#39;s%20Model%20College%20(Autonomous)!5e0!3m2!1sen!2sin!4v1734189759433!5m2!1sen!2sin"/n
 width="1400" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>


 <main>
    
        <section id="contact">
            <h2>Advent Chembio Pvt Ltd</h2>
            <p>w-288 TTC Industrial Area,MIDC Industrial Area,Rabale,Navi Mumbai,Maharastra</p>
        </section>
        <section id="services">
            <h2>FDA approved manufacturing Facility</h2>
            <p>W-279,MIDC,TTC Rabale,Navi Mumbai-4007001</p>
        </section>
        <section id="contact">
            <h2>Center WareHouse</h2>
            <p>Sri Arihant Complex,Building No.1-12,Kalher village,at koper Bhivandi,Thane-421301</p>
        </section>
    </main>
    <footer>
        <p>Advent</p>
    </footer>

    <script>
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>

<style>

body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}


header {
    background-color: black;
    color: white;
    padding: 10px;
}

nav ul {
    display: flex;
    justify-content: center;
    list-style-type: none;
}

nav ul li {
    margin: 0 15px;
}

nav ul li a {
    color: white;
    text-decoration: none;
    font-size: 16px;
}

nav ul li a:hover {
    text-decoration: underline;
}



#hero h1 {
    font-size: 3rem;
    margin-bottom: 10px;
}

#hero p {
    font-size: 1.2rem;
}


#about {
    padding: 60px 20px;
    background-color: black;
    text-align: center;
}

#about h2 {
    font-size: 2rem;
    margin-bottom: 20px;
}

#about p {
    font-size: 1rem;
    line-height: 1.6;
}


#services {
    padding: 60px 20px;
    background-color: black;
    text-align: center;
}

#services h2 {
    font-size: 2rem;
    margin-bottom: 20px;
}

#services p {
    font-size: 1rem;
    line-height: 1.6;
}


#contact {
    padding: 60px 20px;
    background-color: black;
    text-align: center;
}

#contact h2 {
    font-size: 2rem;
    margin-bottom: 20px;
}

#contact p {
    font-size: 1rem;
    line-height: 1.6;
}

footer {
    background-color: grey;
    color: white;
    padding: 20px;
    text-align: center;
}


@media (max-width: 768px) {
    #hero {
        height: 70vh;
    }

    #hero h1 {
        font-size: 2rem;
    }

    #hero p {
        font-size: 1rem;
    }

    nav ul {
        flex-direction: column;
    }

    nav ul li {
        margin: 10px 0;
    }

    #about, #services, #contact {
        padding: 40px 20px;
    }

    footer {
        padding: 10px;
    }
}
</style>

